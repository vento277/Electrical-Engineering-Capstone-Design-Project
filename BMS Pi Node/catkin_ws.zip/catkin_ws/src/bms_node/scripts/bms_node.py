#!/usr/bin/env python3

import rospy
import struct  # For byte-to-float conversion
from std_msgs.msg import Float32MultiArray
from smbus2 import SMBus

I2C_BUS = 1
I2C_ADDRESS = 0x08

def read_floats():
    """Reads 20 bytes from I2C and converts them to two floats."""
    try:
        with SMBus(I2C_BUS) as bus: #Data sent in single message [V_cell1, V_cell2, Vcell_3, Vcell_4, I]
            data = bus.read_i2c_block_data(I2C_ADDRESS, 0, 20)  # Read 8 bytes
            float_values = struct.unpack('fffff', bytearray(data))  # Convert to two floats
            # rospy.loginfo(data)
            return float_values
    except Exception as e:
        rospy.logerr(f"I2C Read Error: {e}")
        return None

def i2c_publisher():
    """ROS node that reads two floats from I2C and publishes them."""
    rospy.init_node('i2c_node', anonymous=True)
    pub = rospy.Publisher('/i2c_floats', Float32MultiArray, queue_size=10)
    rate = rospy.Rate(0.5)  # 1 Hz loop
    V_max = 4.2 # Voltage of fully charged 4S LiPo cell = 16.8V, 4.2V per cell
    V_min = 3.0 # Voltage of dead 4S LiPo cell = 12.0V, 3V per cell
    SoC = 100 # Battery State of charge
    flag_bad = 0

    while not rospy.is_shutdown():
        values = read_floats()
        if values is not None:
            msg = Float32MultiArray()
            msg.data = list(values) # values[0]=voltage, values[1]=current

            volt_1 = values[0] * 4.755
            volt_2 = values[1] * 4.755
            volt_3 = values[2] * 4.755
            volt_4 = values[3] * 4.755

            if (3.0 < volt_1 < 3.7): flag_bad = 1
            # if (3.0 < volt_2 < 3.7): flag_bad = 1
            # if (3.0 < volt_3 < 3.7): flag_bad = 1
            # if (3.0 < volt_4 < 3.7): flag_bad = 1

            rospy.loginfo(f"Received Floats from MCU: V_Cell 1: {volt_1:.2f}V, V_cell 2: {volt_2:.2f}, V_cell 3: {volt_3:.2f}, V_cell 4: {volt_4:.2f}, Flag: {flag_bad:.2f}")
            pub.publish(msg)

            # Compute Battery Percentage, currently only using V_cell 1, multiply by 2 to correct voltage divider
            V_battery = volt_1

            SoC = int((V_battery - V_min)/(V_max - V_min)*100)
            rospy.loginfo(f"Battery Percentage: {SoC}")

        rate.sleep()

if __name__ == '__main__':
    try:
        i2c_publisher()
    except rospy.ROSInterruptException:
        pass
